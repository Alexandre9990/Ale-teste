YSI - Y_Less' Server Includes
=============================

A huge number of includes for simplifying many aspects of SA:MP server development.  See these two topics for more information:

http://forum.sa-mp.com/showthread.php?t=321092

http://forum.sa-mp.com/showthread.php?t=431794
